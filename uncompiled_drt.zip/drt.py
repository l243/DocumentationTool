from tkinter import Tk, Entry, Button, Label, Text, Canvas, PhotoImage, Frame, IntVar, messagebox, StringVar, Menu, Toplevel
from tkinter.ttk import Combobox, Checkbutton, Style
from PIL import ImageTk, Image
from os import getcwd

class gw:
    def create_widget(widget, parent, x, y, w, h, **kwargs):
        obj = widget(parent)
        obj.config(**kwargs)
        obj.place(x=x, y=y, width=w, height=h)
        root.update()
        return obj

def screen_xy(wnd, x, y):
    sc_x = (wnd.winfo_screenwidth() / 2) - (x / 2)
    sc_y = (wnd.winfo_screenheight() / 2) - (y / 2)
    return sc_x, sc_y

def copy_to_clipboard(widget):
    global r

    if r == None:
        # Not pretty, just so you know. The alternative is much more complicated.
        r = Tk()
        r.withdraw()
        r.clipboard_clear() # Clear the clipboard
        r.clipboard_append(widget.get("1.0", "end")) # Push textbox value to clipboard
        r.update() # Now it stays on the clipboard after the window is closed
        r.destroy()
        r = None

def process():
    global stat
    global tran
    global adjs
    temp_string = ""
    provided_info = ""
    vendor_provided_info.clear()
    
    if title_var.get() == "Provider Fields":
        for child in frame_provider.winfo_children():
            if child.winfo_class() == "Label":
                if child.cget("text") == "T/C" and not child.tk_focusNext().get() == "":
                    temp_string += "T/C "
                else:
                    if child.tk_focusNext().winfo_class() == "Entry" and not child.tk_focusNext().get() == "":
                        temp_string += "%s " % child.cget("text")
                    if child.tk_focusNext().winfo_class() == "Text" and not child.tk_focusNext().get("1.0", "end") == "\n":
                        temp_string += "%s " % child.cget("text").strip()
            elif child.winfo_class() == "Text":
                if not child.get("1.0", "end") == "\n":
                    temp_string += "%s" % child.get("1.0", "end")
                    if child.tk_focusPrev().winfo_class() == "TCheckbutton": temp_string += "\n"
            elif child.winfo_class() == "Button":
                if not medrec_att.get() == "" and child.cget("text").find("Medical") > -1:
                    if medrec_att.get() == "1st attempt":
                        temp_string += "%s medical records for DOS: %s %s" % (medrec_att.get(), medrec_dos.get(), medrec_not.get())
                    else:
                        temp_string += "%s to follow up medical records for DOS: %s %s" % (medrec_att.get(), medrec_dos.get(), medrec_not.get())
                if not workstat_att.get() == "" and child.cget("text").find("Work") > -1:
                    if workstat_att.get() == "1st attempt":
                        temp_string += "%s work status for DOS: %s %s" % (workstat_att.get(), workstat_dos.get(), workstat_not.get())
                    else:
                        temp_string += "%s to follow up work status for DOS: %s %s" % (workstat_att.get(), workstat_dos.get(), workstat_not.get())
                if not ordref_att.get() == "" and child.cget("text").find("Referral") > -1:
                    if ordref_att.get() == "1st attempt":
                        temp_string += "%s orders/referrals for DOS: %s %s" % (ordref_att.get(), ordref_dos.get(), ordref_not.get())
                    else:
                        temp_string += "%s to follow up orders/referrals for DOS: %s %s" % (ordref_att.get(), ordref_dos.get(), ordref_not.get())
            elif child.winfo_class() == "TCheckbutton" or child.winfo_class() == "Frame":
                continue
            else:
                if not child.get() == "":
                    temp_string += "%s\n" % child.get()
    else:
        for child in frame_vendor.winfo_children():
            if child.winfo_class() == "Label":
                if child.cget("text") == "T/C" and not child.tk_focusNext().get() == "":
                    if text_doc_viewed_vn.get("1.0", "end") == "\n":
                        temp_string += "T/C "
                    else:
                        temp_string += "\nT/C "
                elif child.cget("text") == "Additional Information":
                    temp_string += "\n%s " % child.cget("text")
                else:
                    if child.tk_focusNext().winfo_class() == "Entry" and not child.tk_focusNext().get() == "":
                        temp_string += "%s " % child.cget("text")
                    if child.tk_focusNext().winfo_class() == "Text" and not child.tk_focusNext().get("1.0", "end") == "\n":
                        temp_string += "%s " % child.cget("text")
                
                if child.tk_focusNext().winfo_class() == "TCombobox" and not child.tk_focusNext().get() == "":
                    if child.cget("text") == "Order":
                        if followup_var.get() == 0:
                            temp_string += "Ordered "
                        else:
                            temp_string += "Follow up "
                    else:
                        temp_string += "%s " % child.cget("text")
                    
                if child.cget("text") == "Appointment Date/Time":
                    stat = True
                    tran = True
                if child.cget("text") == "Additional Information":
                    adjs = True
            elif child.winfo_class() == "Text":
                if not child.get("1.0", "end") == "\n":
                    temp_string += "%s" % child.get("1.0", "end")
                if adjs == True:
                    if not entry_ncm_email.get() == "" or not entry_adj_email.get() == "":
                        temp_string = "%s\n\n%s email to be sent to " % (temp_string, combobox_type.get())
                        if not entry_ncm_email.get() == "" and entry_adj_email.get() == "":
                            temp_string = "%s%s" % (temp_string, entry_ncm_email.get())
                        elif entry_ncm_email.get() == "" and not entry_adj_email.get() == "":
                            temp_string = "%s adj email @ %s" % (temp_string, entry_ncm_email.get())
                        else:
                            temp_string = "%s%s; adj email @ %s" % (temp_string, entry_ncm_email.get(), entry_adj_email.get())
                    
                    if include_email.get() == 1:
                        temp_string += "; usz.claims.cmtaskassignment@zurichna.com"
                    adjs = False
            elif child.winfo_class() == "TCombobox":
                temp_string = "%s%s\n" % (temp_string, child.get())
                if child.tk_focusNext().winfo_class() == "TCheckbutton":
                    if ncm_info_provided_var.get() == 1:
                        vendor_provided_info.append("NCM")
                    if prov_adj_var.get() == 1:
                        vendor_provided_info.append("adjuster")
                    if prov_iw_var.get() == 1:
                        vendor_provided_info.append("IW")

                    for item in vendor_provided_info:
                        provided_info += "%s, " % item

                    if len(vendor_provided_info) > 0:
                        temp_string = "%sProvided %s information\n" % (temp_string, provided_info[0:len(provided_info)-2])
            elif child.winfo_class() == "TCheckbutton" or child.winfo_class() == "Frame" or child.winfo_class() == "Button":
                continue
            else:
                if not child.get() == "":
                    temp_string += "%s\n" % child.get()

                if stat == True:
                    if not body_part.get() == "":
                        temp_string += "Body Part: %s\n" % body_part.get()
                    if not frequency.get() == "":
                        temp_string += "Frequency: %s\n" % frequency.get()
                    if not stats_hgt.get() == "":
                        temp_string += "Height: %s\n" % stats_hgt.get()
                    if not stats_wgt.get() == "":
                        temp_string += "Weight: %s\n" % stats_wgt.get()
                    stat = False

                if tran == True and child.tk_focusPrev().tk_focusPrev().winfo_class() == "TCombobox":
                    if not language.get() == "":
                        temp_string += "Language: %s\n" % language.get()
                    if not pu_addr.get() == "":
                        temp_string += "Pickup address: %s\n" % pu_addr.get()
                    if not do_addr.get() == "":
                        temp_string += "Drop off address and/or MD address: %s\n" % do_addr.get()
                    if not vehicle.get() == "":
                        temp_string += "Type of Vehicle: %s\n" % vehicle.get()
                    tran = False

    if demog_info_verified_var.get() == 1:
        temp_string = "IW demographics/claim info verified\n%s" % temp_string
    if notes_viewed_var.get() == 1:
        temp_string = "Notes viewed on file\n\n%s" % temp_string

    if ncm_info_provided_var.get() == 1 and title_var.get() == "Provider Fields":
        temp_string = "%sProvided NCM information\n" % temp_string

    temp_string += "\n"
    for rediary in rediary_info:
        temp_string = "%s\n%s" % (temp_string, rediary)

    text_review.delete("1.0", "end")
    text_review.insert("1.0", temp_string)

def switch_fields(e):
    frame_vendor.place_forget()
    frame_provider.place_forget()
    
    if title_var.get() == "Provider Fields":
        title_var.set("Vendor Fields")
        frame_vendor.place(x=25, y=100, width=950, height=500)
        text_doc_viewed_vn.focus()
    else:
        title_var.set("Provider Fields")
        frame_provider.place(x=25, y=100, width=950, height=500)
        text_doc_viewed_pr.focus()
    root.update()

def save_attempt():
    if not combobox_attempt.get() == "":
        if frame_title_var.get() == "MEDICAL RECORDS":
            medrec_att.set(combobox_attempt.get())
            medrec_dos.set(entry_dos.get())
            medrec_not.set(text_note.get("1.0", "end"))
            medrec_txt.set("%s Medical Records added" % medrec_att.get())
            button_medrec.config(bg="#009688", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
            button_medrec.focus()
        elif frame_title_var.get() == "WORK STATUS":
            workstat_att.set(combobox_attempt.get())
            workstat_dos.set(entry_dos.get())
            workstat_not.set(text_note.get("1.0", "end"))
            workstat_txt.set("%s Work Status added" % workstat_att.get())
            button_workstat.config(bg="#009688", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
            button_workstat.focus()
        else:
            ordref_att.set(combobox_attempt.get())
            ordref_dos.set(entry_dos.get())
            ordref_not.set(text_note.get("1.0", "end"))
            ordref_txt.set("%s Orders/Referrals added" % ordref_att.get())
            button_ordref.config(bg="#009688", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
            button_ordref.focus()

        combobox_attempt.set("")
        entry_dos.delete(0, "end")
        text_note.delete("1.0", "end")

    frame_attempt.place_forget()

def load_attempt():
    combobox_attempt.set("")
    entry_dos.delete(0, "end")
    text_note.delete("1.0", "end")
    
    if frame_title_var.get() == "MEDICAL RECORDS" and not medrec_att.get() == "":
        combobox_attempt.set(medrec_att.get())
        entry_dos.insert(0, medrec_dos.get())
        text_note.insert("1.0", medrec_not.get())
    if frame_title_var.get() == "WORK STATUS" and not workstat_att.get() == "":
        combobox_attempt.set(workstat_att.get())
        entry_dos.insert(0, workstat_dos.get())
        text_note.insert("1.0", workstat_not.get())
    if frame_title_var.get() == "ORDER / REFERRALS" and not ordref_att.get() == "":
        combobox_attempt.set(ordref_att.get())
        entry_dos.insert(0, ordref_dos.get())
        text_note.insert("1.0", ordref_not.get())

def save_rediary():
    if not entry_date.get() == "":
        for rediary in rediary_info:
            if entry_date.get().strip() == rediary.split("to")[0].split(":")[1].strip() and entry_to.get("1.0", "end").strip() == rediary.split("to")[1].strip():
                rediary_info.pop(rediary_info.index(rediary))
                break
        
        rediary_info.append("Rediary date: %s to %s" % (entry_date.get().strip(), entry_to.get("1.0", "end").strip()))
        
    entry_date.delete(0, "end")
    entry_to.delete("1.0", "end")
    if title_var.get() == "Provider Fields":
        if len(rediary_info) == 1:
            button_rediary_pr.config(text="%s Re-diary entry added" % len(rediary_info), bg="#009688", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
        elif len(rediary_info) > 1:
            button_rediary_pr.config(text="%s Re-diary entries added" % len(rediary_info), bg="#009688", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
        else:
            button_rediary_pr.config(text="%s Re-diary entries added" % len(rediary_info), bg="#FFB347", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
        button_rediary_pr.focus()
    else:
        if len(rediary_info) == 1:
            button_rediary_vn.config(text="%s Re-diary entry added" % len(rediary_info), bg="#009688", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
        elif len(rediary_info) > 1:
            button_rediary_vn.config(text="%s Re-diary entries added" % len(rediary_info), bg="#009688", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
        else:
            button_rediary_vn.config(text="%s Re-diary entries added" % len(rediary_info), bg="#FFB347", fg="#FFFFFF", font=("Segoe UI", 8, "bold"))
        button_rediary_vn.focus()
    

def load_next_rediary():
    entry_date.delete(0, "end")
    entry_to.delete("1.0", "end")

    for rediary in rediary_info:
        entry_date.insert(0, rediary.split("to")[0].split(":")[1].strip())
        entry_to.insert("1.0", rediary.split("to")[1].strip())
        rediary_info.append(rediary_info.pop(rediary_info.index(rediary)))
        break

def remove_rediary():
    if messagebox.askquestion("Delete rediary entry", "This will remove this rediary entry. Continue?") == "yes":
        rediary_info.pop(rediary_info.index("Rediary date: %s to %s" % (entry_date.get().strip(), entry_to.get("1.0", "end").strip())))
        if messagebox.askquestion("Delete rediary entry", "Do you want to clear the fields?") == "yes":
            entry_date.delete(0, "end")
            entry_to.delete("1.0", "end")

def reset_fields():
    global stat
    global tran
    global adjs

    stat = False
    tran = False
    adjs = False

    rediary_info.clear()
    vendor_provided_info.clear()
    vendor_ncmadj_email.clear()

    medrec_att.set("")
    medrec_dos.set("")
    medrec_not.set("")
    workstat_att.set("")
    workstat_dos.set("")
    workstat_not.set("")
    ordref_att.set("")
    ordref_dos.set("")
    ordref_not.set("")

    followup_var.set(0)
    vendor_provided_info.clear()
    
    if title_var.get() == "Provider Fields":
        for child in frame_provider.winfo_children():
            if child.winfo_class() == "Entry":
                child.delete(0, "end")
            elif child.winfo_class() == "Text":
                child.delete("1.0", "end")

        medrec_txt.set("Add attempt | Medical Records")
        workstat_txt.set("Add attempt | Work Status")
        ordref_txt.set("Add attempt | Orders/Referrals")
        button_medrec.config(bg="SystemButtonFace", fg="#000000", font=("Segoe UI", 8))
        button_workstat.config(bg="SystemButtonFace", fg="#000000", font=("Segoe UI", 8))
        button_ordref.config(bg="SystemButtonFace", fg="#000000", font=("Segoe UI", 8))
        button_rediary_pr.config(text="Add Re-diary entry", bg="SystemButtonFace", fg="#000000", font=("Segoe UI", 8))
        text_doc_viewed_pr.focus()
    else:
        for child in frame_vendor.winfo_children():
            if child.winfo_class() == "Entry":
                child.delete(0, "end")
            elif child.winfo_class() == "Text":
                child.delete("1.0", "end")
            elif child.winfo_class() == "TCombobox":
                child.set("")
        
        ncm_name.set("")
        ncm_email.set("")
        adj_name.set("")
        adj_email.set("")
        include_email.set(0)

        body_part.set("")
        frequency.set("")
        stats_hgt.set("")
        stats_wgt.set("")

        language.set("")
        pu_addr.set("")
        do_addr.set("")
        vehicle.set("")

        frame_stats.place_forget()
        frame_adjus.place_forget()
        frame_trans.place_forget()

        button_stats.config(bg="SystemButtonFace", fg="#000000", font=("Segoe UI", 8))
        button_trans_vn.config(bg="SystemButtonFace", fg="#000000", font=("Segoe UI", 8))
        button_adjname.config(bg="SystemButtonFace", fg="#000000", font=("Segoe UI", 8))

        button_rediary_vn.config(text="Add Re-diary entry", bg="SystemButtonFace", fg="#000000", font=("Segoe UI", 8))
        text_additional2_vn.insert("1.0", "Ref#")
        text_doc_viewed_vn.focus()

def onblur(event):
    if event.state == 0:
        event.widget.tk_focusNext().focus()
    else:
        event.widget.tk_focusPrev().focus()
    return "break"

def check_contents(frame, button):
    is_complete = True
    
    button.config(bg="#009688", fg="#FFFFFF")
    for child in frame.winfo_children():
        if child.winfo_class() == "Entry":
            if child.get() == "":
                is_complete = False
                button.config(bg="#FFB347", fg="#FFFFFF")
                break

if __name__ == "__main__":
    root_ht = 630 # Set initial window height
    root_wd = 1000 # Set initial window width

    root = Tk()
    root.title("Documentation Tool")
    root.geometry('%dx%d+%d+%d' % (root_wd, root_ht, screen_xy(root, root_wd, root_ht)[0], screen_xy(root, root_wd, root_ht)[1])) # Screen placement/dimension
    root.resizable(0, 0) # Prevent window resizing
    root.iconbitmap(r"%s\assets\icon_.ico" % getcwd())
    root.config(bg="#FFFFFF")

    vendor_provided_info = []
    rediary_info = []
    vendor_ncmadj_email = []
    
    r = None
    n = 0
    index = 1

    stat = False
    tran = False
    adjs = False

    ##########################################################

    frm_opn = IntVar()
    frm_opn.set(0)
    frame_title_var = StringVar()
    att1 = StringVar()

    notes_viewed_var = IntVar()
    demog_info_verified_var = IntVar()
    ncm_info_provided_var = IntVar()
    followup_var = IntVar()

    ncm_name = StringVar()
    ncm_email = StringVar()
    adj_name = StringVar()
    adj_email = StringVar()
    include_email = IntVar()
    include_email.set(0)

    medrec_txt = StringVar()
    medrec_att = StringVar()
    medrec_dos = StringVar()
    medrec_not = StringVar()
    workstat_txt = StringVar()
    workstat_att = StringVar()
    workstat_dos = StringVar()
    workstat_not = StringVar()
    ordref_txt = StringVar()
    ordref_att = StringVar()
    ordref_dos = StringVar()
    ordref_not = StringVar()

    body_part = StringVar()
    frequency = StringVar()
    stats_hgt = StringVar()
    stats_wgt = StringVar()

    language = StringVar()
    pu_addr = StringVar()
    do_addr = StringVar()
    vehicle = StringVar()

    medrec_txt.set("Add attempt | Medical Records")
    workstat_txt.set("Add attempt | Work Status")
    ordref_txt.set("Add attempt | Orders/Referrals")

    root.update()

    title_var = StringVar()
    title_var.set("Provider Fields")

    ttk_style = Style()
    ttk_style.configure("TCheckbutton", background="#FFFFFF", font=("Segoe UI", 8))
    ttk_style.configure("EA.TCheckbutton", background="#F9F9F9", font=("Segoe UI", 8))
    
    frame_header = gw.create_widget(Frame, root, 0, 0, root_wd, 50, bg="#344955")
    frame_title = gw.create_widget(Frame, root, root_wd - 400, 55, 350, 35, bg="#FFFFFF")
    frame_provider = gw.create_widget(Frame, root, 25, 100, 950, 500, bg="#FFFFFF")
    frame_vendor = gw.create_widget(Frame, root, 25, 100, 950, 500, bg="#FFFFFF")

    blank_wnd = None
    def create_toplevel_window():
        global blank_wnd

        def close_blank_wnd():
            global blank_wnd

            blank_wnd.destroy()
            blank_wnd = None
        
        if blank_wnd == None:
            blank_wnd = Toplevel()
            blank_wnd.title("Blank Template")
            blank_wnd.iconbitmap(r"%s\assets\icon_.ico" % getcwd())
            blank_wnd.geometry("%dx%d+%d+%d" % (400, 350, screen_xy(root, 400, 350)[0], screen_xy(root, 400, 350)[1]))
            blank_wnd.update()
            text_blank = gw.create_widget(Text, blank_wnd, 10, 10, blank_wnd.winfo_width() - 20, blank_wnd.winfo_height() - 50, font=("Segoe UI", 10), bd=3, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
            button_clear_text = gw.create_widget(Button, blank_wnd, blank_wnd.winfo_width() - 110, blank_wnd.winfo_height() - 33, 100, 25, text="Clear", command=lambda : text_blank.delete("1.0", "end"))

            blank_wnd.bind("<Configure>", lambda _ : (text_blank.place(x=10, y=10, width=blank_wnd.winfo_width() - 20, height=blank_wnd.winfo_height() - 50), \
                                                      button_clear_text.place(x=blank_wnd.winfo_width() - 110, y=blank_wnd.winfo_height() - 33, width=100, height=25)))
            blank_wnd.protocol("WM_DELETE_WINDOW", close_blank_wnd)
            
    button_add_blank_text = gw.create_widget(Button, root, 50, 57, 25, 25, text="1", relief="flat", bg="#FFFFFF", fg="#000000", bd=0, font=("Wingdings 2", 12), activebackground="#FFFFFF", command=create_toplevel_window, takefocus=0)
    button_add_blank_text2 = gw.create_widget(Button, root, 75, 57, 135, 25, text="Create Blank Template", relief="flat", bg="#FFFFFF", fg="#000000", bd=0, font=("Segoe UI", 10), anchor="w", activebackground="#FFFFFF", command=create_toplevel_window, takefocus=0)

##    menubar = Menu(root)
##    file_menu = Menu(menubar, tearoff=0)
##    file_menu.add_command(label="Create Blank Template      Ctrl+N", command=lambda : create_toplevel_window())
##    file_menu.add_separator()
##    file_menu.add_command(label="Exit", command=lambda : root.destroy())
##    menubar.add_cascade(label="File", menu=file_menu)
##    root.config(menu=menubar)
    root.bind("<Control-n>", lambda _ : create_toplevel_window())
    
    label_title = gw.create_widget(Label, frame_title, 5, 5, 200, 25, text="DOCUMENTATION TOOL", font=("Segoe UI", 11, "bold"), anchor="e", bg="#FFFFFF")
    separator_title = gw.create_widget(Canvas, frame_title, 216, 5, 1, 24, bg="#E3E3E3", bd=0, highlightthickness=0)
    button_field = gw.create_widget(Label, frame_title, 227, 5, 140, 25, textvariable=title_var, font=("Segoe UI", 11), anchor="w", bg="#FFFFFF", cursor="hand2")
    button_field_arrow = gw.create_widget(Label, frame_title, 337, 5, 10, 25, text="u", font=("Wingdings 3", 11), bg="#FFFFFF", fg="#009688", cursor="hand2")
    button_field.bind("<Button-1>", lambda e : (reset_fields(), switch_fields(e)))
    button_field_arrow.bind("<Button-1>", lambda e : (reset_fields(), switch_fields(e)))

    ## Provider Fields ##

    label_doc_viewed = gw.create_widget(Label, frame_provider, 25, 15, 200, 25, text="Documents viewed on file", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    text_doc_viewed_pr = gw.create_widget(Text, frame_provider, 25, 40, 275, 135, font=("Segoe UI", 10), bd=3, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    text_doc_viewed_pr.bind("<Tab>", lambda event : onblur(event))
    text_doc_viewed_pr.focus()
    label_tc_pr = gw.create_widget(Label, frame_provider, 335, 15, 200, 25, text="T/C", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_tc_pr = gw.create_widget(Entry, frame_provider, 335, 40, 275, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_nov = gw.create_widget(Label, frame_provider, 335, 70, 200, 25, text="Next Appointment Date/Time", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_nov = gw.create_widget(Entry, frame_provider, 335, 95, 275, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_lvm = gw.create_widget(Label, frame_provider, 335, 125, 200, 25, text="Left VM to", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_lvm = gw.create_widget(Entry, frame_provider, 335, 150, 275, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")

    label_iw_attended = gw.create_widget(Label, frame_provider, 645, 15, 135, 25, text="Verified IW attended", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_iw_attended = gw.create_widget(Entry, frame_provider, 645, 40, 275, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    
    written_request_var = StringVar()
    written_request_var.set("Faxed written request @")
    label_written_request = gw.create_widget(Label, frame_provider, 645, 70, 250, 25, textvariable=written_request_var, font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_written_request = gw.create_widget(Entry, frame_provider, 645, 95, 275, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    checkbox_written_request = gw.create_widget(Checkbutton, frame_provider, 759, 120, 175, 25, text="Voice prompted instruction", onvalue="Per voice prompt, faxed written request @", offvalue="Faxed written request @", variable=written_request_var)

    shadow_medrec = gw.create_widget(Frame, frame_provider, 29, 224, 203, 33, bg="#C0C0C0")
    button_medrec = gw.create_widget(Button, frame_provider, 30, 225, 200, 30, textvariable=medrec_txt, font=("Segoe UI", 8), bd=0, cursor="hand2", command=lambda : (frame_title_var.set("MEDICAL RECORDS"), frame_attempt.place(x=(root.winfo_width() / 2) - 350, y=(root.winfo_height() / 2) - 200, width=700, height=400), load_attempt(), combobox_attempt.focus()))
    shadow_workstat = gw.create_widget(Frame, frame_provider, 259, 224, 203, 33, bg="#C0C0C0")
    button_workstat = gw.create_widget(Button, frame_provider, 260, 225, 200, 30, textvariable=workstat_txt, font=("Segoe UI", 8), bd=0, cursor="hand2", command=lambda : (frame_title_var.set("WORK STATUS"), frame_attempt.place(x=(root.winfo_width() / 2) - 350, y=(root.winfo_height() / 2) - 200, width=700, height=400), load_attempt(), combobox_attempt.focus()))
    shadow_ordref = gw.create_widget(Frame, frame_provider, 489, 224, 203, 33, bg="#C0C0C0")
    button_ordref = gw.create_widget(Button, frame_provider, 490, 225, 200, 30, textvariable=ordref_txt, font=("Segoe UI", 8), bd=0, cursor="hand2", command=lambda : (frame_title_var.set("ORDER / REFERRALS"), frame_attempt.place(x=(root.winfo_width() / 2) - 350, y=(root.winfo_height() / 2) - 200, width=700, height=400), load_attempt(), combobox_attempt.focus()))
    shadow_rediary = gw.create_widget(Frame, frame_provider, 719, 224, 203, 33, bg="#C0C0C0")
    button_rediary_pr = gw.create_widget(Button, frame_provider, 720, 225, 200, 30, text="Add Re-diary entry", font=("Segoe UI", 8), bd=0, cursor="hand2", command=lambda : (frame_title_var.set("RE-DIARY NOTES"), frame_rediary.place(x=(root.winfo_width() / 2) - 350, y=(root.winfo_height() / 2) - 200, width=700, height=400), entry_date.focus()))

    label_additional1_pr = gw.create_widget(Label, frame_provider, 25, 300, 275, 25, text="Current treatment plan / Additional orders", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    text_additional1_pr = gw.create_widget(Text, frame_provider, 25, 325, 275, 135, font=("Segoe UI", 10), bd=3, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    text_additional1_pr.bind("<Tab>", lambda event : onblur(event))
    label_additional2_pr = gw.create_widget(Label, frame_provider, 335, 300, 200, 25, text="Additional Information", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    text_additional2_pr = gw.create_widget(Text, frame_provider, 335, 325, 275, 135, font=("Segoe UI", 10), bd=3, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    text_additional2_pr.bind("<Tab>", lambda event : onblur(event))
##    frame_provider.place_forget()

    ## End Provider Fields ##

    ## Vendor Fields ##

    label_doc_viewed = gw.create_widget(Label, frame_vendor, 25, 15, 200, 25, text="Documents viewed on file", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    text_doc_viewed_vn = gw.create_widget(Text, frame_vendor, 25, 40, 275, 135, font=("Segoe UI", 10), bd=3, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    text_doc_viewed_vn.bind("<Tab>", lambda event : onblur(event))
    label_tc_vn = gw.create_widget(Label, frame_vendor, 335, 15, 200, 25, text="T/C", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_tc_vn = gw.create_widget(Entry, frame_vendor, 335, 40, 275, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_order = gw.create_widget(Label, frame_vendor, 335, 70, 200, 25, text="Order", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    combobox_order = gw.create_widget(Combobox, frame_vendor, 335, 95, 275, 25, font=("Segoe UI", 10))
    for line in open(r"%s\vendor_orders.txt" % getcwd(), "r").readlines():
        combobox_order["values"] = (*combobox_order["values"], line.replace("\n", ""))

    def check(event):
        if event.widget.get().find("Translat") > -1 or event.widget.get().find("Transport") > -1:
            button_trans_vn.place(x=260, y=225, width=200, height=30)
            shadow_button_trans.place(x=262, y=227, width=200, height=30)
        else:
            button_trans_vn.place_forget()
            shadow_button_trans.place_forget()
        
    combobox_order.bind("<<ComboboxSelected>>", lambda event : check(event))
    checkbox_followup = gw.create_widget(Checkbutton, frame_vendor, 537, 70, 100, 25, text="Follow up", variable=followup_var)

    label_task_detail = gw.create_widget(Label, frame_vendor, 335, 125, 100, 25, text="Task Detail", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_task_detail = gw.create_widget(Entry, frame_vendor, 335, 150, 180, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_hand_carry = gw.create_widget(Label, frame_vendor, 530, 125, 80, 25, text="Hand Carry CD", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    combobox_hand_carry = gw.create_widget(Combobox, frame_vendor, 530, 150, 80, 25, font=("Segoe UI", 10))
    combobox_hand_carry["values"] = ("", "Yes", "No")

    label_appt_date = gw.create_widget(Label, frame_vendor, 645, 15, 135, 25, text="Appointment Date/Time", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_appt_date = gw.create_widget(Entry, frame_vendor, 645, 40, 275, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_faxed_ref = gw.create_widget(Label, frame_vendor, 645, 70, 250, 25, text="Faxed referral @", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    entry_faxed_ref = gw.create_widget(Entry, frame_vendor, 645, 95, 275, 25, font=("Segoe UI", 10), bd=1, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")

    shadow_button_stats = gw.create_widget(Frame, frame_vendor, 29, 224, 203, 33, bg="#C0C0C0")
    button_stats = gw.create_widget(Button, frame_vendor, 30, 225, 200, 30, text="Statistics", font=("Segoe UI", 8), bd=0, cursor="hand2", \
                                    command=lambda : (frame_stats.place(x=55, y=360, width=400, height=240) if not frame_stats.winfo_ismapped() else frame_stats.place_forget(), frame_trans.place_forget(), frame_adjus.place_forget(), frame_rediary.place_forget(), entry_body.focus(), check_contents(frame_stats, button_stats)))
    shadow_button_trans = gw.create_widget(Frame, frame_vendor, 259, 224, 203, 33, bg="#C0C0C0")
    button_trans_vn = gw.create_widget(Button, frame_vendor, 260, 225, 200, 30, text="Transport / Translate", font=("Segoe UI", 8), bd=0, cursor="hand2", \
                                       command=lambda : (frame_trans.place(x=285, y=360, width=410, height=240) if not frame_trans.winfo_ismapped() else frame_trans.place_forget(), frame_stats.place_forget(), frame_adjus.place_forget(), entry_lang.focus(), check_contents(frame_trans, button_trans_vn)))
    shadow_adjname = gw.create_widget(Frame, frame_vendor, 489, 224, 203, 33, bg="#C0C0C0")
    button_adjname = gw.create_widget(Button, frame_vendor, 490, 225, 200, 30, text="NCM/Adjuster Information", font=("Segoe UI", 8), bd=0, cursor="hand2", \
                                      command=lambda : (frame_adjus.place(x=515, y=360, width=410, height=240) if not frame_adjus.winfo_ismapped() else frame_adjus.place_forget(), frame_trans.place_forget(), frame_stats.place_forget(), check_contents(frame_adjus, button_adjname), combobox_type.focus()))
    shadow_button_rediary = gw.create_widget(Frame, frame_vendor, 719, 224, 203, 33, bg="#C0C0C0")
    button_rediary_vn = gw.create_widget(Button, frame_vendor, 720, 225, 200, 30, text="Add Re-diary entry", font=("Segoe UI", 8), bd=0, cursor="hand2", \
                                         command=lambda : (frame_title_var.set("RE-DIARY NOTES"), frame_rediary.place(x=(root.winfo_width() / 2) - 350, y=(root.winfo_height() / 2) - 200, width=700, height=400), frame_stats.place_forget(), frame_trans.place_forget(), frame_adjus.place_forget(), entry_date.focus()))
    button_trans_vn.place_forget()
    shadow_button_trans.place_forget()

    label_additional1_vn = gw.create_widget(Label, frame_vendor, 25, 300, 275, 25, text="Special instructions given", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    text_additional1_vn = gw.create_widget(Text, frame_vendor, 25, 325, 275, 135, font=("Segoe UI", 10), bd=3, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    text_additional1_vn.bind("<Tab>", lambda event : onblur(event))
    label_additional2_vn = gw.create_widget(Label, frame_vendor, 335, 300, 200, 25, text="Additional Information", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    text_additional2_vn = gw.create_widget(Text, frame_vendor, 335, 325, 275, 135, font=("Segoe UI", 10), bd=3, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    text_additional2_vn.insert("1.0", "Ref#")
    text_additional2_vn.bind("<Tab>", lambda event : onblur(event))

    prov_adj_var = IntVar()
    checkbox_prov_adj = gw.create_widget(Checkbutton, frame_vendor, 645, 401, 275, 25, text="Provided Adjuster information", variable=prov_adj_var)

    prov_iw_var = IntVar()
    checkbox_prov_iw = gw.create_widget(Checkbutton, frame_vendor, 645, 423, 275, 25, text="Provided IW information", variable=prov_iw_var)
    
    frame_vendor.place_forget()

    ## End Vendor Fields ##

    separator1 = gw.create_widget(Canvas, root, 0, 85, root_wd, 10, bg="#FFFFFF", bd=0, highlightthickness=0)
    separator1.create_line(35, 5, 960, 5, fill="#E3E3E3")
    separator2 = gw.create_widget(Canvas, root, 0, 300, root_wd, 10, bg="#FFFFFF", bd=0, highlightthickness=0)
    separator2.create_line(35, 5, 960, 5, fill="#E3E3E3")
    separator3 = gw.create_widget(Canvas, root, 0, 370, root_wd, 10, bg="#FFFFFF", bd=0, highlightthickness=0)
    separator3.create_line(35, 5, 960, 5, fill="#E3E3E3")
    separator4 = gw.create_widget(Canvas, root, 670, 420, 290, 10, bg="#FFFFFF", bd=0, highlightthickness=0)
    separator4.create_line(0, 5, 960, 5, fill="#E3E3E3")

    label_addtlnotes = gw.create_widget(Label, root, 670, 400, 200, 25, text="Additional Documentation Notes", font=("Segoe UI", 8, "bold"), anchor="w", bg="#FFFFFF")
    checkbox_notes_viewed = gw.create_widget(Checkbutton, root, 670, 435, 275, 25, text="Notes viewed on file", variable=notes_viewed_var)
    checkbox_demog_info_verified = gw.create_widget(Checkbutton, root, 670, 457, 275, 25, text="IW demographics/claim info verified", variable=demog_info_verified_var)
    checkbox_ncm_info_provided = gw.create_widget(Checkbutton, root, 670, 479, 275, 25, text="Provided NCM information", variable=ncm_info_provided_var)

    ## Frame - Attempts ##

    frame_attempt = gw.create_widget(Frame, root, (root.winfo_width() / 2) - 350, (root.winfo_height() / 2) - 200, 700, 400, bd=1, highlightbackground="#808080", highlightthickness=1, bg="#F9F9F9")
    
    label_attempt_title = gw.create_widget(Label, frame_attempt, 407, 25, 145, 25, textvariable=frame_title_var, font=("Segoe UI", 10, "bold"), bg="#F9F9F9", anchor="e")
    label_attempt_title2 = gw.create_widget(Label, frame_attempt, 557, 25, 100, 25, text="|   Add Attempt", font=("Segoe UI", 10), bg="#F9F9F9")
    separator_attempt = gw.create_widget(Canvas, frame_attempt, 0, 50, 660, 10, bg="#F9F9F9", bd=0, highlightthickness=0)
    separator_attempt.create_line(35, 5, 960, 5, fill="#E3E3E3")
    label_attempt = gw.create_widget(Label, frame_attempt, 35, 80, 100, 25, text="Attempt", font=("Segoe UI", 8, "bold"), bg="#F9F9F9", anchor="e")
    combobox_attempt = gw.create_widget(Combobox, frame_attempt, 165, 80, 200, 25, font=("Segoe UI", 10))
    combobox_attempt["values"] = ("", "1st attempt", "2nd attempt", "3rd attempt", "4th attempt", "5th attempt", "6th attempt", "7th attempt", "8th attempt", "9th attempt", "10th attempt")
    label_dos = gw.create_widget(Label, frame_attempt, 35, 115, 100, 25, text="Date of Service", font=("Segoe UI", 8, "bold"), bg="#F9F9F9", anchor="e")
    entry_dos = gw.create_widget(Entry, frame_attempt, 165, 115, 200, 25, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_note = gw.create_widget(Label, frame_attempt, 35, 150, 100, 25, text="Note", font=("Segoe UI", 8, "bold"), bg="#F9F9F9", anchor="e")
    text_note = gw.create_widget(Text, frame_attempt, 165, 150, 460, 150, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    text_note.bind("<Tab>", lambda event : onblur(event))

    shadow_button_save = gw.create_widget(Frame, frame_attempt, (frame_attempt.winfo_width() - 138), 332, 100, 40, bg="#C0C0C0")
    button_save_attempt = gw.create_widget(Button, frame_attempt, (frame_attempt.winfo_width() - 140), 330, 100, 40, text="SAVE", relief="flat", font=("Segoe UI", 8, "bold"), bg="#03DAC6", fg="#FFFFFF", cursor="hand2", activebackground="#03DAC6", activeforeground="#FFFFFF", bd=0, \
                                           command=save_attempt)
    shadow_button_cancel = gw.create_widget(Frame, frame_attempt, (frame_attempt.winfo_width() - 258), 332, 100, 40, bg="#C0C0C0")
    button_cancel_attempt = gw.create_widget(Button, frame_attempt, (frame_attempt.winfo_width() - 260), 330, 100, 40, text="CANCEL", relief="flat", font=("Segoe UI", 8, "bold"), bg="#E3E3E3", fg="#000000", cursor="hand2", activebackground="#FF0000", activeforeground="#FFFFFF", bd=0, command=lambda : frame_attempt.place_forget())
    frame_attempt.place_forget()

    ## End Frame - Attempts ##

    ## Frame Re-diary ##

    frame_rediary = gw.create_widget(Frame, root, (root.winfo_width() / 2) - 350, (root.winfo_height() / 2) - 200, 700, 400, bd=1, highlightbackground="#808080", highlightthickness=1, bg="#F9F9F9")
    shadow_button_save = gw.create_widget(Label, frame_rediary, (frame_attempt.winfo_width() - 138), 332, 100, 40, bg="#C0C0C0")
    button_save_rediary = gw.create_widget(Button, frame_rediary, (frame_attempt.winfo_width() - 140), 330, 100, 40, text="SAVE", relief="flat", font=("Segoe UI", 8, "bold"), bg="#03DAC6", fg="#FFFFFF", cursor="hand2", activebackground="#03DAC6", activeforeground="#FFFFFF", bd=0, takefocus=0, \
                                           command=lambda : (save_rediary(), frame_rediary.place_forget()))
    shadow_button_cancel = gw.create_widget(Label, frame_rediary, (frame_attempt.winfo_width() - 258), 332, 100, 40, bg="#C0C0C0")
    button_cancel_rediary = gw.create_widget(Button, frame_rediary, (frame_attempt.winfo_width() - 260), 330, 100, 40, text="CANCEL", relief="flat", font=("Segoe UI", 8, "bold"), bg="#E3E3E3", fg="#000000", cursor="hand2", activebackground="#FF0000", activeforeground="#FFFFFF", bd=0, \
                                             command=lambda : (entry_date.delete(0, "end"), entry_to.delete("1.0", "end"), frame_rediary.place_forget()), takefocus=0)

    label_title = gw.create_widget(Label, frame_rediary, 414, 25, 145, 25, textvariable=frame_title_var, font=("Segoe UI", 10, "bold"), bg="#F9F9F9", anchor="e")
    label_title2 = gw.create_widget(Label, frame_rediary, 557, 25, 100, 25, text="|   Add Entry", font=("Segoe UI", 10), bg="#F9F9F9")
    separator_rediary = gw.create_widget(Canvas, frame_rediary, 0, 50, 660, 10, bg="#F9F9F9", bd=0, highlightthickness=0)
    separator_rediary.create_line(35, 5, 960, 5, fill="#E3E3E3")
    label_date = gw.create_widget(Label, frame_rediary, 10, 80, 100, 25, text="Date", font=("Segoe UI", 8, "bold"), bg="#F9F9F9", anchor="e")
    entry_date = gw.create_widget(Entry, frame_rediary, 140, 80, 200, 25, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_to = gw.create_widget(Label, frame_rediary, 10, 115, 100, 25, text="to", font=("Segoe UI", 8, "bold"), bg="#F9F9F9", anchor="e")
    entry_to = gw.create_widget(Text, frame_rediary, 140, 115, 480, 150, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    entry_to.bind("<Tab>", lambda event : onblur(event))
    shadow_button_add = gw.create_widget(Frame, frame_rediary, 139, 274, 127, 27, bg="#808080")
    button_add = gw.create_widget(Button, frame_rediary, 140, 275, 125, 25, text="+ Add new entry", font=("Segoe UI", 8, "bold"), cursor="hand2", bd=0, command=lambda : (save_rediary(), entry_date.focus()))
    shadow_button_nx = gw.create_widget(Frame, frame_rediary, 579, 274, 42, 27, bg="#808080")
    button_nx_entry = gw.create_widget(Button, frame_rediary, 580, 275, 40, 25, text="u", font=("Wingdings 3", 8), relief="flat", bd=0, command=load_next_rediary)

    shadow_button_remove = gw.create_widget(Frame, frame_rediary, 349, 79, 32, 27, bg="#808080")
    button_remove_rediary = gw.create_widget(Button, frame_rediary, 350, 80, 30, 25, text="3", font=("Wingdings 2", 12), bd=0, relief="flat", command=remove_rediary)
    frame_rediary.place_forget()

    ## End Frame Re-diary ##

    shadow_reset_btn = gw.create_widget(Label, root, 841, 556, 51, 41, bg="#C0C0C0")
    button_reset = gw.create_widget(Button, root, 840, 555, 50, 40, text="Q", font=("Wingdings 3", 14), relief="flat", bg="#F2F2F2", fg="#909090", activebackground="#FF8888", activeforeground="#FFFFFF", highlightthickness=1, bd=0, cursor="hand2", takefocus=0, command=reset_fields)
    shadow_review_btn = gw.create_widget(Label, root, 906, 556, 51, 41, bg="#C0C0C0")
    button_review = gw.create_widget(Button, root, 905, 555, 50, 40, text="g", font=("Wingdings 3", 14, "bold"), relief="flat", bg="#03DAC6", fg="#FFFFFF", activebackground="#03DAC6", activeforeground="#FFFFFF", highlightthickness=1, bd=0, cursor="hand2", command=lambda : (process(), frame_review.place(x=(root.winfo_width() / 2) - 300, y=25, width=600, height=575)), takefocus=0)
    button_review.bind("<Enter>", lambda _ : (button_review.place(x=835, y=555, width=120, height=40), shadow_review_btn.place(x=836, y=556, width=121, height=41), button_review.config(text="REVIEW", font=("Segoe UI", 10, "bold")), button_reset.place(x=770, y=555, width=50, height=40), shadow_reset_btn.place(x=771, y=556, width=51, height=41)))
    button_review.bind("<Leave>", lambda _ : (button_review.place(x=905, y=555, width=50, height=40), shadow_review_btn.place(x=906, y=556, width=51, height=41), button_review.config(text="g", font=("Wingdings 3", 14, "bold")), button_reset.place(x=840, y=555, width=50, height=40), shadow_reset_btn.place(x=841, y=556, width=51, height=41)))
    button_reset.bind("<Enter>", lambda _ : (button_reset.config(text="RESET", font=("Segoe UI", 10, "bold"), bg="#FF8888", fg="#FFFFFF"), button_reset.place(x=770, y=555, width=120, height=40), shadow_reset_btn.place(x=771, y=556, width=121, height=41)))
    button_reset.bind("<Leave>", lambda _ : (button_reset.config(text="Q", font=("Wingdings 3", 14), bg="#F2F2F2", fg="#909090"), button_reset.place(x=840, y=555, width=50, height=40), shadow_reset_btn.place(x=841, y=556, width=51, height=41)))

    ## Review Frame ##

    frame_review = gw.create_widget(Frame, root, (root.winfo_width() / 2) - 300, 25, 600, 575, bd=1, highlightbackground="#808080", highlightthickness=1, bg="#F9F9F9")
    label_title_review = gw.create_widget(Label, frame_review, 10, 3, 300, 25, text="REVIEW DOCUMENTATION PROGRESS", font=("Segoe UI", 8), bg="#F9F9F9", anchor="w")
    button_close_review = gw.create_widget(Button, frame_review, frame_review.winfo_width() - 38, -1, 35, 25, text="X", relief="flat", font=("Segoe UI", 10, "bold"), cursor="hand2", bd=0, bg="#F9F9F9", activebackground="#FF0000", activeforeground="#FFFFFF", takefocus=0, command=lambda : frame_review.place_forget())
    button_close_review.bind("<Enter>", lambda _ : (button_close_review.config(bg="#FF0000", fg="#FFFFFF")))
    button_close_review.bind("<Leave>", lambda _ : (button_close_review.config(bg="#F9F9F9", fg="#000000")))
    text_review = gw.create_widget(Text, frame_review, 25, 50, 545, 450, font=("Segoe UI", 10), bd=3, highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    text_review.bind("<Tab>", lambda event : onblur(event))
    shadow_copy_review_btn = gw.create_widget(Label, frame_review, frame_review.winfo_width() - 151, frame_review.winfo_height() - 61, 123, 33, bg="#C0C0C0", relief="flat")
    button_copy_review = gw.create_widget(Button, frame_review, frame_review.winfo_width() - 150, frame_review.winfo_height() - 60, 120, 30, text="COPY TO CLIPBOARD", font=("Segoe UI", 8), bg="#03DAC6", fg="#FFFFFF", activebackground="#03DAC6", activeforeground="#FFFFFF", relief="flat", bd=0, command=lambda : copy_to_clipboard(text_review))
    frame_review.place_forget()

    ## End Review Frame

    ## Statistics Frame ##

    frame_stats = gw.create_widget(Frame, root, 55, 360, 400, 240, bd=1, highlightbackground="#808080", highlightthickness=1, bg="#F9F9F9")
    label_body = gw.create_widget(Label, frame_stats, 25, 45, 80, 25, text="Body Part", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_body = gw.create_widget(Entry, frame_stats, 120, 45, 250, 25, textvariable=body_part, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_freq = gw.create_widget(Label, frame_stats, 25, 80, 80, 25, text="Frequency", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_freq = gw.create_widget(Entry, frame_stats, 120, 80, 250, 25, textvariable=frequency, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_hgt = gw.create_widget(Label, frame_stats, 25, 115, 80, 25, text="Height", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_hgt = gw.create_widget(Entry, frame_stats, 120, 115, 250, 25, textvariable=stats_hgt, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_wgt = gw.create_widget(Label, frame_stats, 25, 150, 80, 25, text="Weight", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_wgt = gw.create_widget(Entry, frame_stats, 120, 150, 250, 25, textvariable=stats_wgt, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")

    button_close_stats = gw.create_widget(Button, frame_stats, frame_stats.winfo_width() - 38, -1, 35, 25, text="X", relief="flat", font=("Segoe UI", 10, "bold"), cursor="hand2", bd=0, bg="#F9F9F9", activebackground="#FF0000", activeforeground="#FFFFFF", takefocus=0, command=lambda : (frame_stats.place_forget(), check_contents(frame_stats, button_stats)))
    button_close_stats.bind("<Enter>", lambda _ : (button_close_stats.config(bg="#FF0000", fg="#FFFFFF")))
    button_close_stats.bind("<Leave>", lambda _ : (button_close_stats.config(bg="#F9F9F9", fg="#000000")))

    shadow_save_stats = gw.create_widget(Frame, frame_stats, frame_stats.winfo_width() - 88, frame_stats.winfo_height() - 53, 60, 30, bg="#C0C0C0")
    button_save_stats = gw.create_widget(Button, frame_stats, frame_stats.winfo_width() - 90, frame_stats.winfo_height() - 55, 60, 30, text="SAVE", font=("Segoe UI", 8), bg="#03DAC6", fg="#FFFFFF", activebackground="#03DAC6", activeforeground="#FFFFFF", relief="flat", bd=0, \
                                         command=lambda : (body_part.set(entry_body.get()), frequency.set(entry_freq.get()), stats_hgt.set(entry_hgt.get()), stats_wgt.set(entry_wgt.get()), frame_stats.place_forget(), check_contents(frame_stats, button_stats)))
    frame_stats.place_forget()

    ## End Statistics Frame ##

    ## Transportation / Translation Services Frame ##

    frame_trans = gw.create_widget(Frame, root, 285, 360, 410, 240, bd=1, highlightbackground="#808080", highlightthickness=1, bg="#F9F9F9")
    label_lang = gw.create_widget(Label, frame_trans, 25, 45, 90, 25, text="Language", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_lang = gw.create_widget(Entry, frame_trans, 130, 45, 250, 25, textvariable=language, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_pu_addr = gw.create_widget(Label, frame_trans, 25, 80, 90, 25, text="Pick up address", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_pu_addr = gw.create_widget(Entry, frame_trans, 130, 80, 250, 25, textvariable=pu_addr, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_dr_addr = gw.create_widget(Label, frame_trans, 25, 115, 90, 25, text="Drop off address", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_dr_addr = gw.create_widget(Entry, frame_trans, 130, 115, 250, 25, textvariable=do_addr, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_vehicle = gw.create_widget(Label, frame_trans, 25, 150, 90, 25, text="Type of vehicle", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_vehicle = gw.create_widget(Entry, frame_trans, 130, 150, 250, 25, textvariable=vehicle, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")

    button_close_stats = gw.create_widget(Button, frame_trans, frame_trans.winfo_width() - 38, -1, 35, 25, text="X", relief="flat", font=("Segoe UI", 10, "bold"), cursor="hand2", bd=0, bg="#F9F9F9", activebackground="#FF0000", activeforeground="#FFFFFF", takefocus=0, command=lambda : (frame_trans.place_forget(), check_contents(frame_trans, button_trans_vn)))
    button_close_stats.bind("<Enter>", lambda _ : (button_close_stats.config(bg="#FF0000", fg="#FFFFFF")))
    button_close_stats.bind("<Leave>", lambda _ : (button_close_stats.config(bg="#F9F9F9", fg="#000000")))

    shadow_save_trans = gw.create_widget(Frame, frame_trans, frame_trans.winfo_width() - 88, frame_trans.winfo_height() - 53, 60, 30, bg="#C0C0C0")
    button_save_trans = gw.create_widget(Button, frame_trans, frame_trans.winfo_width() - 90, frame_trans.winfo_height() - 55, 60, 30, text="SAVE", font=("Segoe UI", 8), bg="#03DAC6", fg="#FFFFFF", activebackground="#03DAC6", activeforeground="#FFFFFF", relief="flat", bd=0, command=lambda : (frame_trans.place_forget(),check_contents(frame_trans, button_trans_vn)))
    frame_trans.place_forget()

    ## End Transport/Translate Frame ##

    ## NCM / Adjuster Name Frame ##

    frame_adjus = gw.create_widget(Frame, root, 515, 360, 410, 240, bd=1, highlightbackground="#808080", highlightthickness=1, bg="#F9F9F9")
    label_type = gw.create_widget(Label, frame_adjus, 25, 45, 90, 25, text="Type", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    combobox_type = gw.create_widget(Combobox, frame_adjus, 130, 45, 250, 25)
    combobox_type["values"] = ("Confirmation", "Schedule")
    combobox_type.set("Confirmation")
##    label_ncm_name = gw.create_widget(Label, frame_adjus, 25, 45, 90, 25, text="NCM name", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
##    entry_ncm_name = gw.create_widget(Entry, frame_adjus, 130, 45, 250, 25, textvariable=ncm_name, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_ncm_email = gw.create_widget(Label, frame_adjus, 25, 80, 90, 25, text="NCM email", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_ncm_email = gw.create_widget(Entry, frame_adjus, 130, 80, 250, 25, textvariable=ncm_email, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
##    label_adj_name = gw.create_widget(Label, frame_adjus, 25, 115, 90, 25, text="Adjuster name", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
##    entry_adj_name = gw.create_widget(Entry, frame_adjus, 130, 115, 250, 25, textvariable=adj_name, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    label_adj_email = gw.create_widget(Label, frame_adjus, 25, 115, 90, 25, text="Adjuster email", anchor="e", bg="#F9F9F9", font=("Segoe UI", 8, "bold"))
    entry_adj_email = gw.create_widget(Entry, frame_adjus, 130, 115, 250, 25, textvariable=adj_email, bd=1, font=("Segoe UI", 10), highlightthickness=1, relief="flat", highlightbackground="#808080", highlightcolor="#0078D7")
    checkbox_email = gw.create_widget(Checkbutton, frame_adjus, 128, 150, 180, 25, text="Include task assignment email", variable=include_email, style="EA.TCheckbutton")

    button_close_stats = gw.create_widget(Button, frame_adjus, frame_adjus.winfo_width() - 38, -1, 35, 25, text="X", relief="flat", font=("Segoe UI", 10, "bold"), cursor="hand2", bd=0, bg="#F9F9F9", activebackground="#FF0000", activeforeground="#FFFFFF", takefocus=0, command=lambda : (frame_adjus.place_forget(), check_contents(frame_adjus, button_adjname)))
    button_close_stats.bind("<Enter>", lambda _ : (button_close_stats.config(bg="#FF0000", fg="#FFFFFF")))
    button_close_stats.bind("<Leave>", lambda _ : (button_close_stats.config(bg="#F9F9F9", fg="#000000")))

    shadow_save_trans = gw.create_widget(Frame, frame_adjus, frame_adjus.winfo_width() - 88, frame_adjus.winfo_height() - 53, 60, 30, bg="#C0C0C0")
    button_save_trans = gw.create_widget(Button, frame_adjus, frame_adjus.winfo_width() - 90, frame_adjus.winfo_height() - 55, 60, 30, text="SAVE", font=("Segoe UI", 8), bg="#03DAC6", fg="#FFFFFF", activebackground="#03DAC6", activeforeground="#FFFFFF", relief="flat", bd=0, command=lambda : (frame_adjus.place_forget(), check_contents(frame_adjus, button_adjname)))
    frame_adjus.place_forget()

    ## End NCM/Adjuster Frame ##
    
    root.mainloop()
