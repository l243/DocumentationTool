from sys import argv
from cx_Freeze import setup, Executable
from os import environ, path, __file__

PYTHON_INSTALL_DIR = path.dirname(path.dirname(__file__))
environ['TCL_LIBRARY'] = path.join(PYTHON_INSTALL_DIR, 'tcl', 'tcl8.6')
environ['TK_LIBRARY'] = path.join(PYTHON_INSTALL_DIR, 'tcl', 'tk8.6')

build_exe_options = {
    "packages": ["tkinter", "tkinter.ttk", "PIL", "os", "sys", "re", "hashlib"],
    "excludes": ["PyQt4", "numpy", "matplotlib", "time", "webbrowser", "dominate", "dominate.tags"],
    "include_files": [
        path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tk86t.dll'),
        path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tcl86t.dll'),
        path.dirname(path.abspath(argv[0])) + "\\assets",
        path.dirname(path.abspath(argv[0])) + "\\vendor_orders.txt"
    ],
    "optimize": 2
}


setup(
    name = "NCM Documentation Tool",
    version = "2.6.9",
    options = {"build_exe": build_exe_options},
    description = "A documentation reference tool",
    executables = [Executable(path.dirname(path.abspath(argv[0])) + "\\drt.py", base="Win32GUI", icon=path.dirname(path.abspath(argv[0])) + "\\assets\\icon_.ico")])
